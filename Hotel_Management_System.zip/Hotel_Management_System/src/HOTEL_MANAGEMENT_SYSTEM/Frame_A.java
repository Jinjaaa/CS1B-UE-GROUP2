package HOTEL_MANAGEMENT_SYSTEM;
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class Frame_A extends javax.swing.JFrame {

    
    public Frame_A() {
        initComponents();
    Icon i = lbl_h1.getIcon();
    ImageIcon icon= (ImageIcon)i;
    Image image=icon.getImage().getScaledInstance(lbl_h1.getWidth(),lbl_h1.getHeight(), Image.SCALE_SMOOTH);
    lbl_h1.setIcon(new ImageIcon(image));
    us1.setVisible(false);
    
    
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        b1 = new javax.swing.JLabel();
        us = new javax.swing.JLabel();
        us1 = new javax.swing.JLabel();
        lbl_h1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1000, 700));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1626, 650, -1, -1));

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));
        jPanel2.setPreferredSize(new java.awt.Dimension(1000, 700));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 30)); // NOI18N
        jLabel1.setText("WELCOME TO ");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 80, 320, 60));

        jLabel2.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 100)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(118, 161, 136));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("U");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 120, 80, 80));

        jLabel3.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 100)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("CAZA AZ  L");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 120, -1, 80));

        b1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/continue.png"))); // NOI18N
        b1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                b1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                b1MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                b1MousePressed(evt);
            }
        });
        jPanel2.add(b1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 200, -1, 40));

        us.setFont(new java.awt.Font("Tw Cen MT", 2, 14)); // NOI18N
        us.setText("Want to know more about us? Click here");
        us.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                usMouseEntered(evt);
            }
        });
        jPanel2.add(us, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 610, -1, 30));

        us1.setFont(new java.awt.Font("Tw Cen MT", 2, 14)); // NOI18N
        us1.setForeground(new java.awt.Color(118, 161, 136));
        us1.setText("Want to know more about us? Click here");
        us1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                us1MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                us1MousePressed(evt);
            }
        });
        jPanel2.add(us1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 610, -1, 30));

        lbl_h1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/h1.jpg"))); // NOI18N
        lbl_h1.setText("jLabel3");
        jPanel2.add(lbl_h1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1200, 770));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1626, 660));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void b1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b1MouseEntered
        b1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/continue2.png")));
    }//GEN-LAST:event_b1MouseEntered

    private void b1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b1MouseExited
        b1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/continue.png")));
    }//GEN-LAST:event_b1MouseExited

    private void b1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b1MousePressed
        new Frame_B().setVisible(true);
        this.dispose();
        
    }//GEN-LAST:event_b1MousePressed

    private void usMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usMouseEntered
        us1.setVisible(true);
        us.setVisible(false);
        
    }//GEN-LAST:event_usMouseEntered

    private void us1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_us1MouseExited
        us.setVisible(true);
        us1.setVisible(false);
    }//GEN-LAST:event_us1MouseExited

    private void us1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_us1MousePressed
        new Frame_A_About().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_us1MousePressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Frame_A.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Frame_A.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Frame_A.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Frame_A.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Frame_A().setVisible(true);
            }
        });
    } 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel b1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lbl_h1;
    private javax.swing.JLabel us;
    private javax.swing.JLabel us1;
    // End of variables declaration//GEN-END:variables
}
